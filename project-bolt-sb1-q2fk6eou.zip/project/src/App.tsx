import React from 'react';
import { ChevronRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 py-4">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-serif text-center">Fashion Blog</h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* First Row: Must-Reads, Main Article, Latest */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Must-Reads Section */}
          <aside className="lg:col-span-3">
            <h2 className="text-xl font-serif mb-6 pb-2 border-b-2 border-gray-200">MUST-READS</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-sm font-medium">Fashion</span>
                  <h3 className="font-serif text-lg leading-snug mt-1">Celebrate the Year of the Dragon With These Lunar New Year Gifts</h3>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <span>By Kevin Huynh</span>
                    <span className="mx-2">•</span>
                    <span>2 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1612215327100-60fc5c4d7938?auto=format&fit=crop&q=80"
                  alt="Lunar New Year"
                  className="w-28 h-28 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-sm font-medium">Oscars</span>
                  <h3 className="font-serif text-lg leading-snug mt-1">The 2025 Oscar Nominations Are Here—Emma Stone Leads With 13 Nods</h3>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <span>By Tessa Petak</span>
                    <span className="mx-2">•</span>
                    <span>3 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80"
                  alt="Oscar nominations"
                  className="w-28 h-28 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-sm font-medium">Boots</span>
                  <h3 className="font-serif text-lg leading-snug mt-1">Brooke Shields's Unexpected Winter Boots Are Making a Comeback</h3>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <span>By Kyra Surgent</span>
                    <span className="mx-2">•</span>
                    <span>4 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&q=80"
                  alt="Winter boots"
                  className="w-28 h-28 object-cover rounded"
                />
              </div>
            </div>
          </aside>

          {/* Main Article */}
          <main className="lg:col-span-6">
            {/* First Article */}
            <article>
              <div className="relative aspect-[16/9] mb-6">
                <img
                  src="https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&q=80"
                  alt="Fashion editorial"
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              
              <div className="text-center max-w-2xl mx-auto">
                <div className="mb-4">
                  <span className="text-red-600 uppercase tracking-wider text-sm font-medium">Fashion</span>
                </div>
                <h2 className="text-4xl font-serif mb-4">The Evolution of Street Style: A Modern Perspective</h2>
                <div className="flex items-center justify-center space-x-4 text-gray-600 text-sm">
                  <span>By Sarah Anderson</span>
                  <span>•</span>
                  <span>5 min read</span>
                </div>
              </div>
            </article>
          </main>

          {/* The Latest Section */}
          <aside className="lg:col-span-3">
            <h2 className="text-xl font-serif mb-6 pb-2 border-b-2 border-gray-200">THE LATEST</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-xs font-medium">Fashion Week</span>
                  <h3 className="font-serif text-base leading-snug mt-1">New York Fashion Week's Street Style Stars Brave the Cold in Statement Coats</h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <span>By Lauren Chan</span>
                    <span className="mx-2">•</span>
                    <span>6 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80"
                  alt="Fashion Week Style"
                  className="w-24 h-24 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-xs font-medium">Celebrity Style</span>
                  <h3 className="font-serif text-base leading-snug mt-1">The Most Memorable Red Carpet Moments Leading Up to Grammy Night</h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <span>By Sarah Johnson</span>
                    <span className="mx-2">•</span>
                    <span>8 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1533929736458-ca588d08c8be?auto=format&fit=crop&q=80"
                  alt="Red Carpet"
                  className="w-24 h-24 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-xs font-medium">Music</span>
                  <h3 className="font-serif text-base leading-snug mt-1">Grammy Predictions: Who Will Win Record of the Year?</h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <span>By Michael Brooks</span>
                    <span className="mx-2">•</span>
                    <span>9 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80"
                  alt="Grammy Award"
                  className="w-24 h-24 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-xs font-medium">Royal Family</span>
                  <h3 className="font-serif text-base leading-snug mt-1">Meghan Markle Embraced Winter Whites at the Invictus Games 2025 Opening Ceremony</h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <span>By Tessa Petak</span>
                    <span className="mx-2">•</span>
                    <span>10 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1604514628550-37477afdf4e3?auto=format&fit=crop&q=80"
                  alt="Meghan Markle"
                  className="w-24 h-24 object-cover rounded"
                />
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <span className="text-red-600 uppercase tracking-wider text-xs font-medium">Celebrity Couples</span>
                  <h3 className="font-serif text-base leading-snug mt-1">Victoria and David Beckham Had a Stylish Night Out With King Charles and Queen Camilla</h3>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <span>By Alicia Brunker</span>
                    <span className="mx-2">•</span>
                    <span>12 HOURS AGO</span>
                  </div>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1600096194534-95cf5ece04cf?auto=format&fit=crop&q=80"
                  alt="Beckham couple"
                  className="w-24 h-24 object-cover rounded"
                />
              </div>

              {/* See More Latest News Button */}
              <button className="w-full text-center text-sm text-gray-500 hover:text-gray-700 transition-colors">
                SEE MORE LATEST NEWS
                <ChevronRight className="inline-block ml-1 w-4 h-4" />
              </button>
            </div>
          </aside>
        </div>

        {/* Grammy Section - Adjusted Width */}
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-9">
            <div className="bg-gray-100 p-12 rounded-lg">
              <h2 className="font-serif text-4xl mb-12">The Grammys! It's Music's Biggest Night</h2>
              
              <div className="grid grid-cols-12 gap-8">
                {/* Main Grammy Article */}
                <div className="col-span-7">
                  <div className="relative">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="Grammy performer"
                      className="w-full aspect-[3/4] object-cover mb-6"
                    />
                    <span className="text-red-600 uppercase tracking-wider text-sm font-medium">GRAMMYS</span>
                    <h3 className="font-serif text-3xl mt-2 mb-3">Our Picks for the Best Looks of the 2025 Grammys</h3>
                    <div className="text-sm text-gray-500">By Kevin Huynh</div>
                  </div>
                </div>

                {/* Related Grammy Stories */}
                <div className="col-span-5 space-y-8">
                  <div className="flex gap-6 items-start">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="Beauty looks"
                      className="w-32 h-32 object-cover"
                    />
                    <div>
                      <span className="text-red-600 uppercase tracking-wider text-xs font-medium">GRAMMYS</span>
                      <h4 className="font-serif text-xl mt-2 mb-2">All the Stunning Beauty Looks from the 2025 Grammys</h4>
                      <div className="text-sm text-gray-500">By Lauren Valenti</div>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="Beyoncé"
                      className="w-32 h-32 object-cover"
                    />
                    <div>
                      <span className="text-red-600 uppercase tracking-wider text-xs font-medium">GRAMMYS</span>
                      <h4 className="font-serif text-xl mt-2 mb-2">A Look Back at All of Beyoncé's Historic Grammy Award Wins</h4>
                      <div className="text-sm text-gray-500">By Emma Backs</div>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="St. Vincent"
                      className="w-32 h-32 object-cover"
                    />
                    <div>
                      <span className="text-red-600 uppercase tracking-wider text-xs font-medium">GRAMMYS</span>
                      <h4 className="font-serif text-xl mt-2 mb-2">Inside St. Vincent's 'Minimalist' '90s Grammys Glam</h4>
                      <div className="text-sm text-gray-500">By Lauren Valenti</div>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="Bianca Censori"
                      className="w-32 h-32 object-cover"
                    />
                    <div>
                      <span className="text-red-600 uppercase tracking-wider text-xs font-medium">GRAMMYS</span>
                      <h4 className="font-serif text-xl mt-2 mb-2">Will Bianca Censori Face Charges for Her Grammys Look?</h4>
                      <div className="text-sm text-gray-500">By Starr Bowenbank</div>
                    </div>
                  </div>

                  <div className="flex gap-6 items-start">
                    <img
                      src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80"
                      alt="Grammy Performances"
                      className="w-32 h-32 object-cover"
                    />
                    <div>
                      <span className="text-red-600 uppercase tracking-wider text-xs font-medium">GRAMMYS</span>
                      <h4 className="font-serif text-xl mt-2 mb-2">The Most Unforgettable Performances of Grammy Night</h4>
                      <div className="text-sm text-gray-500">By Emma Backs</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;